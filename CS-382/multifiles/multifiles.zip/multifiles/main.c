#include <stdio.h>
#include "utils.h"

int main () {
    int area = calculate_area(10);
    printf("%d\n", area);
    return 0;
}
