#include "utils.h"

int calculate_area(int side) {
    return side * side;
}
