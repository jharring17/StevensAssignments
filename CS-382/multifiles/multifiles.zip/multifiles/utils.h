int calculate_area(int);
