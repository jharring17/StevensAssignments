(* 
#############################################################################
#__/                         .- -. -.. .-. . .--                         \__#
#                          Andrew McCauley: CS 496                          #
#__   I pledge my honor that I have abided by the Stevens Honor System.   __#
#  \                   -- -.-. -.-. .- ..- .-.. . -.--                   /  #
#############################################################################
*)
open Ast
open Ds


let rec apply_proc : exp_val -> exp_val -> exp_val ea_result =
  fun f a ->
  match f with
  | ProcVal (id,body,env) ->
    return env >>+
    extend_env id a >>+
    eval_expr body
  | _ -> error "apply_proc: Not a procVal"
and
 eval_expr : expr -> exp_val ea_result = fun e ->
  match e with
  | Int(n) ->
    return @@ NumVal n
  | Var(id) ->
    apply_env id
  | Add(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return @@ NumVal (n1+n2)
  | Sub(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return @@ NumVal (n1-n2)
  | Mul(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return @@ NumVal (n1*n2)
  | Div(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    if n2==0
    then error "Division by zero"
    else return @@ NumVal (n1/n2)
  | Let(id,def,body) ->
    eval_expr def >>=
    extend_env id >>+
    eval_expr body
  | ITE(e1,e2,e3) ->
    eval_expr e1 >>=
    bool_of_boolVal >>= fun b ->
    if b
    then eval_expr e2
    else eval_expr e3
  | IsZero(e) ->
    eval_expr e >>=
    int_of_numVal >>= fun n ->
    return @@ BoolVal (n = 0)
  | Proc(id,e)  ->
    lookup_env >>= fun en ->
    return (ProcVal(id,e,en))
  | App(e1,e2)  ->
    eval_expr e1 >>= fun v1 ->
    eval_expr e2 >>= fun v2 ->
    apply_proc v1 v2
  | Abs(e1)      ->
    eval_expr e1  >>=
    int_of_numVal >>= fun n ->
    return @@ NumVal (abs n)
  | Cons(_e1, _e2) -> failwith "no need to implement"
  | Hd(_e1) ->  failwith "no need to implement"
  | Tl(_e1) ->  failwith "no need to implement"
  | Record(fs) -> if (dupestring (List.map (fun (str,_exp) -> str) fs)) = true
                   then error "Record: duplicate fields"
                   else no_ea((sequence (List.map (fun (s,e) -> (s,eval_expr e)) fs)))
                   
  | Proj(e,id) ->  eval_expr e >>= record_of_recordVal >>= fun r ->
                    if (List.mem id (List.map (fun (st, _exp) -> st) r)) = true
                    then return (getval id r)
                    else error "Proj: field does not exist"
  | Empty(e1)  ->  eval_expr e1 >>= tree_of_treeVal >>= fun t ->
                    if t = Empty
                    then return @@ BoolVal(true)
                    else return @@ BoolVal(false)
  | EmptyList    ->  failwith "no need to implement"
  | EmptyTree ->  return @@ TreeVal(Empty)
  | Node(e1,lte,rte) ->  eval_expr e1 >>= fun e ->
                  eval_expr lte  >>= tree_of_treeVal >>= fun lt ->
                  eval_expr rte >>= tree_of_treeVal >>= fun rt ->
                  return @@ TreeVal (Node(e,lt,rt))
  | CaseT(target,emptycase,id1,id2,id3,nodecase) ->
                  eval_expr target >>= tree_of_treeVal >>= fun t ->
                  (match t with
                  | Empty -> eval_expr emptycase
                  | Node (i1,i2,i3) -> extend_env id1 i1 >>+ extend_env id2 (TreeVal(i2)) >>+ extend_env id3 (TreeVal(i3)) >>+ eval_expr nodecase)
  | Tuple(_es) ->  failwith "no need to implement"
  | Untuple(_ids,_e1,_e2) ->  failwith "no need to implement"
  | _ -> failwith "not implemented"


(***********************************************************************)
(* Everything above this is essentially the same as we saw in lecture. *)
(***********************************************************************)

(* Parse a string into an ast *)





let parse s =
  let lexbuf = Lexing.from_string s in
  let ast = Parser.prog Lexer.read lexbuf in
  ast

let lexer s =
  let lexbuf = Lexing.from_string s
  in Lexer.read lexbuf


(* Interpret an expression *)
let interp (e:string) : exp_val result =
  let c = e |> parse |> eval_expr
  in run c

